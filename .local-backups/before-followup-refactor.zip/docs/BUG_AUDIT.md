# MyCity backend audit and refactor

Reviewed 2026-09-08 against the standalone local source. Scope: all 61 exported original Luau files, now reorganized into 147 files. There is no local Git repository or branch history to inspect. Studio-only scripts/assets may add behavior beyond this export.

## Major issues repaired

| Area | Previous failure | Current implementation |
| --- | --- | --- |
| Startup and hierarchy | Moved scripts still required old parents; deleted remotes stopped startup | Single client/server entry points, feature folders, corrected paths, complete server-created network schema and client leaf waits |
| Failed loads and overlapping sessions | Default/partial data could be saved after a load failure; simultaneous writers could overwrite a city | UpdateAsync lease in Data_1, strict load failures, original-record abandonment after partial restoration, stale-save refusal |
| Nested data | Deep folders did not round-trip and duplicate scalar keys were ambiguous | Recursive codec, legacy folder-name support, duplicate-key rejection; placed-building saves update existing trackers |
| Inventory and tool creation | Competing global factories and early snapshots could lose inventory | One factory, serialization with unique IDs/paid status, restore-before-snapshot, respawn readiness and central tool initialization |
| Remote authority | Clients could submit foreign objects and unconstrained transforms; mutation races were possible | Owned object/tool checks, finite transforms, footprint/height/overlap validation and per-player mutation guard |
| Construction | Broken timer function name, separate builder tables on restore, missing paid CSV flag and destructive completion order | Canonical timer/builder tables, 12-field persistence, rollback on failed setup, placed record committed before removing construction, deterministic IDs |
| Purchase receipts | Retry/rejoin could grant twice; target selection was mutable; transfer removal was not durable | Persisted intents, receipt plans/applied markers, one-profile reward snapshots, owner transfer markers before buyer grants |
| Tutorial | Free/duplicate client-requested tools or milestones; Shack completion did not advance; reconnect lost stage | Server stages, real cash purchase, Bank grant guard, Shack/offline completion and legacy resume |
| Quests and daily rewards | Duplicate construction count, yielding completion rewarded twice, streak timestamp overwritten before checking, repeated button listeners | Single milestone, completion guard, reward preparation, previous timestamp, one button binding |
| Income/population/friends | Reads minted income ticks; payout and displays used different formulas; advertised friend bonus was unpaid | Shared BuildingEconomy calculations, explicit elapsed accrual, server friendship attributes and client attribute updates |
| Redemption codes | Used-code marker saved separately from cash; malformed/concurrent requests reached storage | Typed/guarded requests; legacy history read; new cash and marker saved together in Data_1 |
| HUD/prompts/chat | HUD replacement retained callbacks; prompt UIs detached without destruction; chat shake connections accumulated | Controller connection/task scopes, initialization cancellation, prompt destruction/cleanup, expiring shake connection and nil sender handling |
| Building presentation | Unsupported task handles in attributes, wrong XP billboard path, missing Residential industry metadata | Private pulse thread tracking, corrected billboard path, explicit residential catalogue metadata |
| Configuration | Optional webhook helper embedded a credential | Active source reads optional ServerStorage.MyCitySecrets.PurchaseWebhook; no outbound webhook called by this work |

## Remaining limits and release blockers

These are not claims that every possible gameplay bug is fixed.

1. **Studio migration and integration are unverified.** Run MIGRATION.md and the hierarchy audit. Authored dimensions, UI names, ModuleScript classes, enabled legacy scripts and TopbarPlus cannot be proven from source. Hidden HUD/loading/tool/admin implementations were not available locally. The local chat relay only forwards its author's commands; authorization in an external ControlPanel server remains outside this export.
2. **Purchase recovery has explicit unresolved cases.** A legacy receipt may have no persisted target. A steal may target an item already sold/deleted/completed or an owner with an active lease on another server. These remain NotProcessedYet; there is no cross-server transfer worker or invented compensation. An intent stranded across a disconnect before the platform confirms/cancels its prompt can block a later prompt of the same product. Reconcile against actual receipt history rather than discarding it blindly.
3. **Old servers ignore new session locks.** Drain old SetAsync writers during deployment. A blind rollback to old serialization can drop new metadata. Real DataStore throttling, lease contention, shutdown deadlines and receipt retry timing need dedicated tests.
4. **Persistence metadata grows.** Receipt IDs, transfer markers and redemption records remain for replay protection. Monitor profile size before adding high-volume products; introduce archival only with a design that preserves deduplication.
5. **Authored placement needs play coverage.** Server checks cover bounds/height/yaw/overlap, but grid phase, special buildings, rotations on Plot5-8 and all template sizes have not been verified in Studio.
6. **Secondary stores remain separate.** CityNames and CityRatings retain their existing namespaces. City likes are atomically deduplicated, but the owner's small online cash notification/reward is not a cross-store durable transaction. Weather's automatic cycle remains disabled as in the prior source; enabling it would change game behavior.
7. **Infrastructure failures remain possible.** Retry exhaustion is reported and failed loads are refused; no code can guarantee a final write during an outage or server termination. Real recovery, device and long-session testing is still required.

## Local validation

- `validate_source.luau`: compiles every source/tool Luau file without running gameplay.
- `check_paths.py`: resolves local literal requires; TopbarPlus.Icon is explicitly external. Two dynamic imports are manually reviewed.
- `test_network.luau`: empty/idempotent startup, complete schema, delayed descendant replication, server-only creation and wrong-class errors.
- `test_startup.luau`: late/early readiness, tutorial selection, listener ordering and duplicate HUD initialization.
- `test_persistence.luau`: lease contention/expiry/release/stale writes, malformed profiles, recursive/legacy codec and duplicate keys.
- `test_receipts.luau`: receipt replay, partial save failure, same-server retry, simulated crash/rejoin and unloaded-profile rejection.
- `test_security.luau`: owned placement, invalid/foreign tools, malformed/tilted/floating/out-of-bounds/overlapping placement, foreign buildings, guard/rate/leave behavior.
- `test_cleanup.luau`: callback disconnection, task cancellation, stale callback rejection and scope reuse.
- `test_progression.luau`: authoritative tutorial order, Shack completion, legacy resume, malformed/previously redeemed codes, lookup/save failures and retry deduplication.

These are source and mock-runtime checks. No Studio play session, real payment, published server, mobile session or live DataStore operation was executed. The edit-mode migration and read-only Studio audit are provided for the next integration step.
