# Applying the MyCity refactor in Studio

The source is now organized like the Wordie pattern: one server entry, one client entry, and feature folders with child modules. The authored models and GUI templates also need to follow the moved modules. The migration has been generated locally; it has not been run in your place.

## Edit-mode migration

1. Save a backup copy of the place. Stop Play and pause Script Sync before applying the renamed/deleted source files.
2. Paste `tools/migrate_studio.luau` into Studio's Command Bar in **Edit mode** and run it once. It preflights destination classes and child collisions, moves existing script-owned templates, and disables/archives replaced old scripts under `ServerStorage.MyCityMigrationArchive`. It adds undo waypoints. If it reports a collision, preserve both copies and reconcile the named objects before rerunning.
3. Resume Script Sync and sync the complete `src` tree, including additions and removals. A folder with `init.luau` must be a ModuleScript with children. Do not Play between migration and complete sync: newly created module containers initially have no source.
4. Verify `src/server -> ServerScriptService.server`, `src/shared -> ReplicatedStorage.shared`, and `src/client -> StarterPlayer.StarterPlayerScripts.client` (or directly StarterPlayerScripts).
5. Paste/run `tools/audit_studio.luau` in Edit mode. Resolve every required/source-path error. Review scripts listed outside the sync roots, especially authored Tool/HUD/loading scripts, and export any gameplay code still absent locally. The archive is excluded from that list.
6. Confirm only `server.Main` and client `Initialization` run automatically. Main's Items stays at `server.Main.Items`; PlayerDataModule's Data/leaderstats belong at `server.persistence.PlayerDataModule`. Keep the archived scripts disabled.
7. Start a local test with Events and Functions absent from ReplicatedStorage. Network.start creates all 80 RemoteEvents and 2 RemoteFunctions in their existing feature folders before gameplay starts. A wrong class fails clearly. Do not manually recreate the old folders.

The migration preserves authored templates. It does not create missing buildings, GUI artwork, TopbarPlus, plot models, sounds, or descendants that were never exported. The audit identifies expected objects, but scripts hidden inside those assets still need review.

## Required play checks

- New player: load, Bank tutorial, income collection, buy/place/finish Shack, quest handoff.
- Returning player: inventory, equipped tools, plot orientation (including Plot5-8), nested data, ongoing and offline-completed construction, paid flags, city name and expansion tiles.
- Multiplayer: place/move/collect/delete only owned buildings; reject foreign tools and out-of-bounds/overlapping placement; simultaneous purchases, rebirth, quest completion and leaving.
- Respawn/replace HUD: no duplicate button handlers, orphaned previews, prompts or tutorial camera callbacks; inventory restored once; desktop, touch and controller placement.
- Purchases in a dedicated test environment: repeat the same receipt, disconnect/rejoin between grant steps, failed saves, shop target selection, skips/Build All, cross-player transfers and preserved paid items after rebirth.
- Data failures: failed reads refuse entry; a second server cannot own the same new-format profile; expired/stale saves are refused. Check save budgets under realistic concurrency.
- Long session: building XP, income rates and displayed values, friend bonuses, prompt cleanup, traffic/trains and plot reuse.

## Release and rollback constraints

`Data_1` is deliberately retained. Its record now includes a session lease, recursive folder encoding and purchase/code markers. This is a data-writing change, not just a file rename.

Validate in an isolated test place/store before release. At rollout, drain/restart servers running the previous save implementation: old SetAsync writers do not recognize the new lease. Restoring only the old source is not a safe rollback after new profiles have been written; use a compatible reader/writer or a reviewed data restoration plan.

Unresolved old purchases with no saved target and steals whose owner is on another live server can remain pending. Do not force these to PurchaseGranted. See BUG_AUDIT.md for the exact limits. No live servers were restarted, data stores modified, or place published by this refactor.
