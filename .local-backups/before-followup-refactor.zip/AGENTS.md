# MyCity project handoff

Updated 2026-09-08. Root: `Active Games/MyCity`, the standalone city-building game.
This is not the historical KingdomWars campaign checkout named MyCity.

## Working rules

- Script Sync is the source mapping; there is no Rojo project, place export, or Git repository here.
- Preserve authored models, GUI templates, names, and all unrelated synced changes.
- Read the current tree before editing. The 2026-09-08 refactor expanded 61 source files into 147.
- `docs/MIGRATION.md` explains the required Studio asset migration. It has not been executed in Studio.
- No code-only check establishes published, multiplayer, DataStore, purchase, or device behavior.
- Keep this handoff and `docs/BUG_AUDIT.md` current when behavior changes.
- Do not run maintenance deletion or publish/commit/push as part of routine code work.

## Runtime mapping and authored objects

| Local source | Roblox location |
| --- | --- |
| `src/server` | `ServerScriptService.server` |
| `src/client` | `StarterPlayer.StarterPlayerScripts.client`, or StarterPlayerScripts itself |
| `src/shared` | `ReplicatedStorage.shared` |

Ordinary `.luau` files are ModuleScripts; `init.luau` makes its directory the ModuleScript, with the other files as children. `.local.luau` is a LocalScript and `.legacy.luau` a Script. Preserve the parent-module structure when syncing.

Only `server/Main.legacy.luau` and `client/Initialization.local.luau` are automatic gameplay entry points. Former independent scripts are modules called by these entry points. Maintenance is an unrequired module.

Exact authored names include `shared`, `server`, `MarketPlaceHandler`, `Enviorment`, `HamburgerResturaunt`, `StealBuilding.Recieved`, and `CodeFeeback`. Do not silently correct them.

- Highlight: `ReplicatedStorage.Assets.Highlight`.
- Expansion: `ReplicatedStorage.Assets.Expansion.Locked` and `.Expansion.ExpansionPrompt`.
- Shared effects: `ReplicatedStorage.shared.UIEffects`.
- `server.Main.Items` stays under Main, with building/construction billboards, prompts, SpeechBubble and rarity effects.
- PlayerDataModule's authored `Data` and `leaderstats` move with it to `server.persistence.PlayerDataModule`.
- Client controller templates move with their owning modules. ProximityPromptController keeps Default/themed GUIs; ShopController keeps PurchaseFrame/ItemTemplate; TutorialController keeps beam/anchor templates; UIController keeps its GUI templates.
- `ReplicatedStorage.TopbarPlus.Icon`, Assets models/tools, StarterGui.HUD, Workspace.Map and ServerStorage.PlotTemplate remain authored Studio dependencies.
- ToolFactory disables the template Tool.Init script because BuildingTools now initializes all building tools centrally. Other scripts hidden inside Studio assets still require inspection/export.

## Folder structure and ownership

```text
src/
  server/
    Main.legacy.luau
    bootstrap/                 # ServerBootstrap, PlayerLifecycle
    config/BuildingConfig/     # Catalogue assembled from category modules
    persistence/
      PlayerDataModule/        # ProfileCodec, SchemaMigration, SessionStore
      FunnelAnalytics.luau
    services/
      MarketPlaceHandler/     # ProductConfig, intents, plans, ledger, actions, transfers
      ToolFactory.luau
      ToolSerialization.luau
      ToolSetup.luau
      CodeSystem.luau
    systems/
      building/BuildingSystem/ # Validation, placement commit, data, XP, stats, prompts
      construction/ConstructionSystem/
        ConstructionTimer/    # Timing, Completion, Visuals, Lifecycle
      economy/                 # Inventory, shop, selling, BuildingEconomy, IncomeSystem/
      progression/             # Tutorial, quests, rebirth, daily/group rewards, badges
      world/                   # Plots, expansion, city names, traffic, trains, weather, VFX
      social/                  # CityRating, FriendBoost
      security/                # RequestGuard
    maintenance/               # DeleteDatastore; never automatic
  client/
    Initialization.local.luau
    bootstrap/HudBootstrap.luau
    controllers/
      ui/                      # UIController/, NotificationController/, ProximityPromptController/
      shop/                    # ShopController/, SellController/
      tutorial/TutorialController/
      placement/               # BuildingTools, ExpandHighlight, ToolsModule/Session/
      social/                  # ChatTags, FriendsBoost, LikeSystem
      systems/                 # ResetButton
  shared/
    Network.luau
    UIEffects.luau
    util/ConnectionScope.luau
```

Feature `init.luau` modules assemble focused child modules using an explicit Context. Stable dependencies live on Context, shared mutable state on Context.State. Private cross-module functions use Context; public methods stay on the returned API. Do not copy mutable scalar values into locals and expect reassignment to update shared state.

## Startup and teardown

ServerBootstrap creates the network before requiring gameplay systems, initializes the systems, starts social services, then installs PlayerLifecycle. Weather's autonomous cycle remains disabled as in the previous source; building weather updates still exist.

PlayerLifecycle acquires/restores data, waits for a character, assigns a plot, restores buildings/constructions/expansion/city name, restores inventory, initializes rebirth/tutorial recovery, then sets `MyCityLoaded=true`. Client listeners bind before requesting ClientReady snapshots for shop, quests, daily rewards and rebirth. Early/missed loading events are covered by replicated readiness attributes.

Departure sets `MyCityLeaving`, waits for load and in-flight guarded mutations, settles income, snapshots inventory, saves/releases the profile, then clears world/controller state. BindToClose uses the same departure path. A partial restoration abandons the original acquired record instead of saving a partial city.

HudBootstrap owns HUD replacement. It cancels unfinished initialization, calls controller cleanup and ConnectionScope.clear, then binds the replacement. ConnectionScope tracks signal callbacks and spawned/deferred/delayed work. Long-lived placement/social controllers are started once by Initialization.

## Persistence and transaction rules

- Preserve `Data_1` and the existing JSON envelope (`PlayerData`, `LeaderBoardData`, `LastSaved`). Recursive folders use `FolderEncoding=2`; the codec reads legacy folder keys.
- SessionStore uses UpdateAsync with a 180-second lease in the SAME profile record. Autosave runs every 45 seconds. Saves check the session ID atomically; stale sessions are stopped.
- Do not start new servers alongside old SetAsync writers indefinitely. See the release procedure: old servers cannot honor the new lease.
- Missing/corrupt data and service failures must not become default profiles. Only a missing record is a new profile. Missing authored building templates cause restoration to fail safely.
- Inventory must be restored before taking a snapshot. Unique ToolId identifies each tool; serialization preserves level, XP, mutation, validity and paid status. MyCityInventoryReady gates remote mutations during respawn restoration.
- Requests that mutate inventory/currency/buildings use RequestGuard. Validate ownership, current plot, argument types and spatial bounds on the server.
- ReceiptLedger persists PurchaseId, plan, applied steps and completion in the player profile. A reward and its applied marker are saved together. Never acknowledge a receipt until completion saves.
- PurchaseIntents persist an immutable target before prompting. Do not replace an unresolved intent with another target. Unknown or unavailable targets remain pending; see documented limitations.
- Cross-player steals persist removal and a transfer marker in the owner's profile before granting the buyer. Do not restore the owner's item when retrying a completed transfer.
- New code-redemption markers and cash save together in Data_1; the old `Codes` store remains a read-only source for prior redemptions. `CityNames` and `CityRatings` remain their existing separate stores.
- There is no global tool factory. Use ToolFactory/ToolSerialization.

## Gameplay invariants

- BuildingValidation checks owned tools/models, finite upright quarter-turn placement, footprint on owned land, height, and overlap. Authored grid phase and all special model sizes need Studio checks.
- PlacementCommit prepares instant buildings before committing their saved record and consuming the tool. Construction placement rolls back the site/tracker/builder reservation on setup failure.
- Construction tracks all 12 CSV fields, including paid status. Completed constructions use their construction ID as the placed building ID. Builder/timer tables are canonical across new/restored/skipped construction.
- BuildingEconomy supplies the income/population formulas shared by payout and displays. Only the timer adds elapsed income; recalculation does not mint a tick. Friend boost comes from server friendship checks.
- Tutorial stages: 0 welcome, 1 Bank tool, 2 Bank started, 3 Bank completed, 4 income collected, 5 Shack purchased, 6 Shack started, 7 Shack completed. Only stage 7 can finish. Resume uses persisted stages or existing legacy city/tool evidence.
- Quest completion guards reentry and advances without a presentation delay. Daily streak calculations use the previous claim timestamp. Rebirth preserves paid inventory/buildings/constructions.

## Validation and tools

`tools/check_paths.py` checks literal local requires. TopbarPlus.Icon is Studio-only; the Initialization controller loop and Rebirth's ShopSystem require are dynamic and reviewed manually.

Run the actual Lune binary if the Rokit shim fails:
`C:/Users/636922/.rokit/tool-storage/lune-org/lune/0.10.2/lune.exe`.

Run `validate_source.luau`, then `test_network.luau`, `test_startup.luau`, `test_persistence.luau`, `test_receipts.luau`, `test_security.luau`, `test_cleanup.luau`, and `test_progression.luau` using `lune run tools/<file>`.

These compile/execute source against local mocks; they do not contact Roblox or live DataStores. `audit_studio.luau` checks actual authored paths read-only in Studio. `migrate_studio.luau` performs the edit-mode migration described in docs/MIGRATION.md.

`refactor_layout.py`, `split_modules.py`, and `scope_connections.py` record one-time transformations and must not be rerun on the already-refactored tree. `build_studio_migration.py` can regenerate the migration from `docs/layout-migration.json`. The local pre-refactor backup is `.local-backups/before-deep-refactor.zip`; it includes old sensitive configuration and must not be published.
