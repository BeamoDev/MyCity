# MyCity source audit — 2026-09-08

Reviewed all 61 currently exported Luau files, including the new Network module.
The follow-up migration creates runtime remotes and moves Expansion/UIEffects paths. Findings below are based on source
inspection; no Studio session, purchases, production data, or exploit traffic was
used. This folder is not a Git checkout, so “branches” here means the source tree,
not historical Git branches.

## Completed path and startup fixes

| Change | Files |
| --- | --- |
| Expand highlight now clones ReplicatedStorage.Assets.Highlight | `src/client/ExpandHighlight.local.luau` |
| Shop/tutorial templates resolve under their current modules, removing ReplicatedStorage.Client | `src/shared/ShopController.luau`, `src/shared/TutorialController.luau` |
| Topbar uses its explicit ReplicatedStorage root; cash HUD lookup uses the HUD passed to Init | `src/shared/UIController.luau` |
| Synced GUI and building-tool entry points, per-instance initialization guards, destroyed-tool listener cleanup | `src/client/Initialization.local.luau`, `src/client/BuildingTools.local.luau`, `src/shared/Init.luau`, `src/shared/ToolsModule.luau` |
| Replicated MyCityLoaded state gates tutorial/placement readiness; Main avoids waiting for another character when one already exists | `src/server/Main/init.legacy.luau`, `src/shared/Init.luau`, `src/shared/ToolsModule.luau` |
| Build All searches Plot.Buildings.Construction | `src/server/Main/MarketPlaceHandler/init.luau` |
| Plot offset helper uses Workspace.Map.Plots; reset mugshot uses Plot.UI.Overhead | `src/server/Main/PlotManager.luau` |
| Sell preview cleanup searches Plot.Land.Locked | `src/shared/SellController.luau` |
| Builder-limit event uses Events.Notifications.BuilderLimitReached consistently | `src/server/Main/ConstructionSystem/init.luau`, `src/server/Main/BuildingSystem/BuildingPlacement.luau` |
| Server creates all 79 events and 2 functions before gameplay requires; clients wait for full replication; removed local/late remote creation | `src/shared/Network.luau`, server entry points, shared controllers, ChatTags and SellSystem |
| Friend RemoteFunction moved to Functions.Friends.GetFriendBoost on both ends | `src/server/FriendBoost.legacy.luau`, `src/shared/FriendsBoost.luau` |
| Expansion templates now resolve under Assets.Expansion | `src/server/Main/PlotManager.luau`, `src/server/Main/ExpansionSystem.luau` |
| HUD startup calls shared.UIEffects; existing/new buttons have duplicate-binding guards | `src/shared/Init.luau`, `src/shared/UIEffects.luau` |
| Disabled automatic maintenance deletion and restricted its opt-in execution to Studio | `src/server/Main/DeleteDatastore.legacy.luau` |

Originally the maintenance script had ENABLE_DELETE=true, DELETE_SPECIFIC_ONLY=true,
STUDIO_ONLY=false and user 1790165114 in its deletion list. If enabled as a Script,
every server could remove that user's keys from the listed stores. Its actual
Enabled property and any historical deletions are unknown. No live data was changed
by this audit. Keep the new safe defaults.

## Major unresolved findings

### P0 — Other players' buildings can be moved or deleted without ownership checks

`BuildingSystem/init.luau:156` and `:160` pass remote-provided building instances to
`BuildingSystem/BuildingConfig.luau:108`, `:181`, and `:186`. Those functions never
verify the requester owns the building. Move calls collect, which creates a tool
for the requesting player and destroys the world building; Delete destroys it.
The guarded CollectBuilding handler in Main does not protect these alternate routes.

Impact: a malicious client can affect another city's live buildings and obtain a
tool without purchasing a steal. The victim's saved entry may remain, allowing
duplication on rejoin. Validate Instance class, current membership in the caller's
placed folder, ownership and allowed state inside the shared mutation functions.
Roblox specifically requires server validation of instance references and their
permitted locations. [Client/server security guidance](https://create.roblox.com/docs/scripting/security/client-server-boundary)

### P0 — Failed loads can overwrite a player's real city with defaults

`PlayerDataModule/init.luau:238` catches GetAsync failure but uses the same default
data branch for both failure and a genuinely missing profile (`:256`). That data
is attached to the player, then the 60-second autosave/leave/shutdown path calls
SetAsync at `:173` without a successful-load guard.

Impact: a temporary read outage can turn into permanent progress loss. The loader
must distinguish “no saved record” from “read failed,” reject/quarantine failed
loads, and prevent all writes until loading succeeds. There is also no session
lock: overlapping servers can overwrite one another's complete profile snapshots.
Simply replacing SetAsync with an unconditional UpdateAsync does not solve ownership.

### P0 — Placement trusts the submitted tool and only validates its center position

`BuildingSystem/BuildingPlacement.luau:10` does not check the CFrame type/finite
components, the instance class, or that the tool belongs to the player's current
Backpack/Character. The PlaceBlock handler at `BuildingSystem/init.luau:148` relies
on that function. Collision, full footprint and grid restrictions exist only in
ToolsModule. Server validation checks only whether the center is on an owned tile.

Impact: requests can reference other replicated tools/templates and bypass collision
or footprint rules. The server later destroys the supplied instance. Own the
validation/consumption transaction on the server, including revalidation after
yielding pass checks and preventing concurrent use of the same tool.

### P1 — Purchases can be lost, repeated, or applied to the wrong pending item

`MarketPlaceHandler/init.luau:192` has no PurchaseId ledger and no check that the
profile is loaded. `handleDevProduct` at `:154` can acknowledge a cash receipt even
when leaderstats/Cash is absent. Rewards exist in memory when PurchaseGranted is
returned; saving later can fail. Building packs can partially grant before an error.

`handleShopPurchase` at `:175` consumes a single mutable PendingPurchase name, with
no binding to the received product's price tier. ShopSystem sets it after prompting
at `:292`. Skip/steal targets also live only in temporary attributes/ObjectValues.
Disconnects lose those targets; newer prompts can replace older pending context.
The Build All folder correction does not fix receipt durability.

Impact: purchase retry/crash/rejoin sequences can duplicate rewards, lose paid
items, or leave a receipt pending with no recoverable target. Use verified grant
results, persistent receipt handling and durable product-matched intent. Roblox's
receipt documentation describes PurchaseId-based deduplication and acknowledges
cross-server failure considerations. [ProcessReceipt reference](https://create.roblox.com/docs/reference/engine/classes/MarketplaceService#ProcessReceipt)

### P1 — Paid buildings lose the flag that protects them during rebirth

`ConstructionSystem/ConstructionData.luau:60` writes a 12-field record whose last
field is RobuxBuilding. The live countdown at `ConstructionTimer.luau:383` rewrites
only 11 fields, dropping that flag on its first update. A restored site/building
then becomes a non-Robux item.

Separately, `BuildingSystem/BuildingConfig.luau:108` collects a building into a tool
without copying its RobuxBuilding attribute. `RebirthSystem.clearPlayerProgress`
deletes non-Robux tools/models and filters saved fields 10/12. Impact: paid items
that the design intends to preserve can disappear after pickup or rejoin/rebirth.
Preserve this metadata across every creation, update, transfer and serialization path.

### P1 — Tutorial remotes mint free tools and allow arbitrary completion

`TutorialSystem.luau:183` gives a Shack on every ShackPurchased remote request,
without checking tutorial state, a purchase, or whether one was already granted.
GiveBank at `:169` checks only IsInTutorial and can be repeated. Both Main and
TutorialSystem accept TutorialFinished without validating server-owned milestones.

Impact: free repeatable tools, cash through build/collect/sell, and bypassed
progression. Use a server-owned tutorial state machine and one-time grants; the
client should request an action, not declare payment or completion.

### P1 — Placing a building destroys the tool before construction succeeds

`BuildingSystem/BuildingPlacement.luau:141` destroys the tool before cloning the
final building or starting construction. Construction subsequently checks capacity,
models and templates and can return false or throw. Pass checks yield, so capacity
can also change between validation and placement.

Impact: the player loses their item on a failed placement. Reserve the tool and
builder slot, validate dependencies, then consume on successful commit or restore
the original item on failure. Paid and collected building metadata must survive.

### P1 — Departure saving has an incompatible timestamp type and racing callbacks

`Main/init.legacy.luau:414` assigns an os.date string to LastUpdate, while
`PlayerDataModule/init.luau:72` creates missing LastUpdate as IntValue. For profiles
using that migration default, the assignment can error before final save and plot
reset. An authored StringValue template would change which profiles hit this bug;
its class has not been inspected in Studio.

Main, IncomeSystem and InventorySystem separately handle PlayerRemoving. Main saves
and resets the plot while the other callbacks collect pending income or refresh
inventory; there is no ordered snapshot transaction. Yielding API calls make the
final state timing-dependent. Centralize departure: freeze actions, settle income,
snapshot inventory, save with a bounded retry policy, then release/reset the plot.

### P1 — Quest completion can overlap, double reward, or skip steps

`ConstructionSystem/init.luau:79` and `:86` invoke onConstructionStarted twice for
one site. `PostTutorialQuest.luau:203` rewards a completed quest, then yields for
three seconds at `:213` before advancing the step, without a completing guard.
Another completion during that window sees the same step and may reward it again.

Impact: “construct three buildings” counts incorrectly; simultaneous construction
or population events can duplicate rewards and advance more than one step. Remove
the duplicate call, commit progression before presentation delays and serialize
completion for each player. Test overlapping events and rejoin at completion.

## Additional confirmed source issues

| Finding | Evidence and impact |
| --- | --- |
| Friend boost is not connected to income | `FriendBoost.legacy.luau` checks for IncomeSystem.updatePlayerFriendBoost, which does not exist. IncomeSystem's own boost table stays at zero. Client UI can advertise a bonus not paid by the server. Do not just add a setter that trusts the client percentage. |
| Friend polling runs roughly every frame | `shared/FriendsBoost.luau:86` starts a yielding five-second task on every Heartbeat; it is not one poll every five seconds. This creates overlapping friend API calls. |
| Two different population formulas write the same stat | BuildingSystem.updatePopulation uses logarithmic levels; IncomeSystem.calculatePopulation uses linear levels plus happiness every second. Rebirth eligibility and displays can jump after placement. |
| Displayed building income differs from actual payout | BuildingPrompts uses linear levels and BuildingStats penalties; IncomeSystem uses logarithmic levels and different penalties. Choose one authoritative formula. |
| Income recalculation also mints a tick of income | calculateAndStackBuildingIncome increments accumulated earnings; callers use it after placements, loading, and collection as well as the one-second loop. Separate accumulation from recomputation. |
| Rebirth can remain repeatedly eligible with preserved paid buildings | Rebirth intentionally preserves paid buildings, recomputes population, then yields through ShopSystem.onPlayerRebirth. No in-flight rebirth guard exists. Test paid cities that remain above successive population requirements. |
| Construction stealing is not a durable transfer | Marketplace's construction branch destroys the site and grants a fresh tool without transactionally removing the owner's saved tracker or preserving site level/XP. Timer cleanup happens later; save/rejoin timing can restore the original. |
| Building save migration can duplicate entries | BuildingData.loadPlayerBuildings calls saveBuildingData for an old-format entry, which creates another StringValue with the same name instead of updating the old one. The serializer keys scalar values by name, so duplicate entries are ambiguous and can overwrite each other. |
| Nested profile folders do not round-trip symmetrically | savePlayerData writes a third nested folder level; the loader only restores children with ClassName at its last level, silently skipping deeper folders. Current affected template contents need Studio inspection. |
| First-session/late-client listeners can miss state | Most module listeners are registered in init after yielding requires, and several wait for another CharacterAdded unconditionally. Rebirth/quest/overhead initial state uses one-shot events without a general client-ready snapshot request. MyCityLoaded only addresses tutorial/placement readiness. |
| Loading/in-GUI/tool scripts are not all present in this export | No exported client consumes LoadingProgress/LoadingComplete or fires tutorial ShackPurchased; factories reference a child Tool.Init that is absent from the source tree. Existing Studio scripts may still own these flows. Use the hierarchy audit to locate and export them before claiming a complete migration. |
| Chat camera callbacks never disconnect | ChatTags creates a new RenderStepped connection per shake and merely returns after expiry, retaining each callback. It can also index a nil player in OnIncomingMessage. |
| Commands are forwarded by every receiving client | ChatTags.onMessageReceived forwards any received !cmd- message through ControlPanel.CommandEvent, without limiting to the local author. The ControlPanel server implementation is absent, so permission enforcement cannot be verified. |
| Daily streak expiry is computed after updating the timestamp | DailyRewards.claimReward resets LastClaimTime to now before calculating timeSinceLastClaim, so its missed-days reset branch is unreachable. |
| Daily reward UI accumulates click handlers | UIController.setupDailyRewardUI connects ClaimButton again on each UpdateUI without disconnecting its previous connection. |
| Sell notifications pass incorrect arguments | SellController passes sound names where NotificationController expects the text argument. The missing first-sale remote is fixed by startup creation. |
| Building tier pulse uses an unsupported stored task handle | BuildingXP stores a task thread in an Instance attribute and later treats it as a connection. Its billboard lookup also disagrees with BuildingPrompts' Hitbox.BuildingInfo.Container hierarchy, masking the broken path. |
| Thought bubbles never qualify using the exported catalogue | BuildingThoughts requires config.Industry == Residential; BuildingConfig defines no Industry fields. |
| HUD replacement can retain old controller listeners | Init prevents duplicate startup of the same HUD, but most controllers do not fully disconnect listeners when a different HUD replaces it. Verify authored ResetOnSpawn and respawn behavior. |
| Proximity prompt cleanup retains a detached UI | ProximityPromptScript cleanup sets promptUI.Parent=nil instead of destroying it; its custom input connections are not explicitly cleaned there. Inspect memory growth in a long prompt-heavy session. |

## Validation completed and limits

- All current source files compile with local Lune 0.10.2; compilation executes no
  gameplay or DataStore code.
- `tools/check_paths.py` resolves literal local module requires under the sync
  mapping. TopbarPlus.Icon is explicitly classified as Studio-only; the dynamic
  RebirthSystem ShopSystem require was manually checked against its sibling file.
- `tools/test_startup.luau` checks four mocked cases: late returning client, new
  tutorial client, delayed server completion, and tutorial state changing during
  loading. It also checks duplicate initialization and listener setup before waiting.
- `tools/test_network.luau` executes the actual registry against mocks: empty
  startup, all 81 remotes, repeat initialization preserving references, delayed
  leaf replication, client creation rejection, and wrong-class diagnostics.
- The read-only `tools/audit_studio.luau` is provided but has NOT been executed in
  this place. Passing local checks does not prove authored assets exist or hidden
  scripts have been migrated.
- No published-place, multiplayer, mobile, persistence-failure, real receipt or
  long-session test has been performed. Major unresolved findings above remain open.
