# MyCity project handoff

Last reviewed: 2026-09-08. This is the standalone city-building game at
`C:\Users\636922\Documents\Roblox Development\Active Games\MyCity`.
It is NOT the older KingdomWars campaign checkout with MyCity in its path.

## Scope and source of truth

- This is a Studio Script Sync source export. There is no Rojo project, package
  manifest, place export, or Git repository in the current root.
- User confirmed `src/server` is under `ServerScriptService.server`, `src/shared`
  is `ReplicatedStorage.shared`, and client scripts are under
  `StarterPlayer.StarterPlayerScripts`. The client sync root can be that service's
  `client` Folder or StarterPlayerScripts itself; client entry points do not depend
  on their parent name. The static checker models the `client` Folder layout.
- User confirmed Highlight is now `ReplicatedStorage.Assets.Highlight`, Expansion
  is now `ReplicatedStorage.Assets.Expansion`, and UIEffects moved from
  `ReplicatedStorage.Modules.UIEffects` to `ReplicatedStorage.shared.UIEffects`.
  Other script-owned templates remain under their original scripts/modules.
  Preserve these authored instances. Events/Functions were deleted in Studio;
  the server now creates their full schema at runtime.
- Files arrived through sync during the review. Re-inventory before future work
  and preserve new or unrelated edits. Do not use stale file counts as authority.
- Source review cannot verify Studio Enabled/RunContext properties, template
  contents, remotes, published behavior, receipts, or saved player data.
- `docs/BUG_AUDIT.md` records the current major unresolved bugs and completed fixes.

## Script Sync naming and paths

- `Main/init.legacy.luau` is the running Script `ServerScriptService.server.Main`;
  its neighboring files are CHILDREN of Main, not siblings of an `init` script.
- `BuildingSystem/init.luau`, `ConstructionSystem/init.luau`,
  `PlayerDataModule/init.luau`, and `MarketPlaceHandler/init.luau` are ModuleScripts
  with children. Preserve that nesting for `script.Parent` requires.
- Ordinary `.luau` files are ModuleScripts. `.local.luau` are LocalScripts.
  `.legacy.luau` are legacy-context Scripts. Do not rename these suffixes casually.
- Exact spelling matters: `shared`, `server`, `MarketPlaceHandler`,
  `Enviorment`, `HamburgerResturaunt`, `StealBuilding.Recieved`, and `CodeFeeback`
  are used by the source. Do not silently correct authored names.
- There should be no references to the former `ReplicatedStorage.Client` root in
  synced code. Use relative module references and explicit service roots.
- `src/shared/Network.luau` supports both server and client contexts. The other
  shared modules are client controllers/helpers; do not require them from server code.

## Entry points and initialization

| Source | Responsibility |
| --- | --- |
| `src/server/Main/init.legacy.luau` | Requires and initializes systems, loads player data, assigns plots, restores buildings/constructions, schedules inventory loading, group reward and departure saving |
| `src/server/CityRating.legacy.luau` | Independent city-like persistence, prompts, sign updates and owner cash rewards |
| `src/server/FriendBoost.legacy.luau` | Independent friend boost bridge; currently disconnected from actual income calculation, see audit |
| `src/server/Main/DeleteDatastore.legacy.luau` | Maintenance utility; now `ENABLE_DELETE = false`, `STUDIO_ONLY = true`. Keep both defaults |
| `src/client/Initialization.local.luau` | Finds existing/new `PlayerGui.HUD` ScreenGui and calls `ReplicatedStorage.shared.Init.initialize(hud)` |
| `src/client/BuildingTools.local.luau` | Watches existing/new Backpack and Character tools and initializes ToolsModule for building tools |
| `src/client/ExpandHighlight.local.luau` | Proximity highlight and building/construction billboards, cloning `Assets.Highlight` |
| `src/client/ProximityPromptScript.local.luau` | Custom keyboard/gamepad/touch prompt rendering; retains its `Default` and themed child templates |
| `src/client/Functions.local.luau` | Retries disabling Roblox's reset button through SetCore |
| `src/client/ChatTags.local.luau` | Chat tags, rotating tips, rarity announcements, camera shake and legacy command forwarding |

Main, FriendBoost and CityRating first call `shared.Network.start()` before any
gameplay require. It creates 79 RemoteEvents and 2 RemoteFunctions, preserving
existing correctly typed instances; wrong classes raise a descriptive error.
Clients call `Network.wait()` before controller remote access, waiting for every
schema descendant rather than only root folders. Network has no require-time
creation or dependency on other modules. Add future remotes to its schema.

Main gameplay initialization order is CityName, ToolSetup, Shop, PlotManager, Building,
Income, Expansion, Construction, Marketplace, Sell, Inventory, Codes, Rebirth,
Tutorial, Analytics, Traffic, Trains, PostTutorialQuest, DailyRewards. Weather.init
is commented out. Some modules also start work or register listeners at require
time, so moving requires can change behavior. ToolSetup and TutorialSystem both
assign `_G.CreateToolWithBuilding`; the current require order leaves TutorialSystem's
factory active. Avoid assuming those factories are interchangeable.

The server sets `player.MyCityLoaded` (an ATTRIBUTE) after its five loading phases
are marked complete. Init binds controller listeners, then waits for that state
before choosing tutorial/normal UI. ToolsModule also waits before reading the plot.
This flag survives a missed one-shot LoadingComplete event. It is a presentation
readiness signal, NOT a successful-save/session-lock guarantee: the existing data
loader can return defaults after failure, and inventory is restored later.

Init guards repeated initialization of the same HUD. ToolsModule guards repeated
initialization of the same Tool, handles already-equipped tools, and disconnects
its global CleanupPreview listener when the Tool is destroyed. Existing Tool.Init
scripts inside the authored template are NOT exported here: inspect them for old
paths or duplicate behavior. Same-module guards do not protect against a separate
legacy module copy. HUD replacement/respawn teardown is not fully implemented.

## Gameplay systems and module map

All server paths below are relative to `src/server/Main`.

| Files | Responsibility |
| --- | --- |
| `BuildingConfig.luau` | Building catalogue: cost, size, construction time, income, population, image, rarity, population/rebirth unlocks and decoration status |
| `SpawnConfig.luau` | Weighted locked-tile scenery selection |
| `PlotManager.luau` | Plot1–Plot8 assignment, owned tiles, scenery, signs, spawn placement and cloning ServerStorage plot templates on departure |
| `ExpansionSystem.luau` | Adjacent tile prompts and purchases; 10-wide grid, center tiles 9/10/19/20, price bands |
| `BuildingSystem/init.luau` | Building façade, ownership lookup, population calculation, PlaceBlock and Move/Delete remotes |
| `BuildingSystem/BuildingPlacement.luau` | Placement validation and instant-building/construction branching |
| `BuildingSystem/BuildingConfig.luau` | Runtime per-building ValueObjects, collection/movement and deletion; distinct from the catalogue above |
| `BuildingSystem/BuildingData.luau` | Placed-building CSV encoding, plot-relative position/orientation and restoration |
| `BuildingSystem/BuildingPrompts.luau` | Info/steal prompts, building billboard updates, temporary PendingBuildingUI markers |
| `BuildingSystem/BuildingStealing.luau` | Paid transfer logic and tool factory fallback |
| `BuildingSystem/BuildingXP.luau` | Building XP every 5 seconds, exponential thresholds to level 99, cost/rebirth XP multipliers and tier VFX |
| `BuildingSystem/BuildingStats.luau` | Distance-based crime, fire, health and decoration happiness calculations |
| `BuildingSystem/BuildingThoughts.luau` | Residential speech bubbles; catalogue currently lacks its required Industry field |
| `ConstructionSystem/init.luau` | Creates sites and starts construction; owns shared timer/builder tables |
| `ConstructionSystem/ConstructionData.luau` | Construction CSV persistence, offline elapsed time and restoring/completing sites |
| `ConstructionSystem/ConstructionTimer.luau` | Per-site countdowns, save tracker updates, completion, notifications and tutorial hooks |
| `ConstructionSystem/ConstructionBuilder.luau` | Builder counts, builder pass lookup, builder UI updates |
| `ConstructionSystem/ConstructionSkipping.luau` | Skip/steal prompts and resolving an owned construction identifier |
| `ConstructionSystem/ConstructionVFX.luau` | Placement and completion particles/sounds |
| `IncomeSystem.luau` | Accrues building income, population, multipliers, collection touch handlers and plot displays |
| `ShopSystem.luau` | Per-player stock, 300-second refresh, cash buys and price-tier Robux prompts |
| `SellSystem.luau` | Equipped-tool sale eligibility, value/profit calculation and sale notifications |
| `InventorySystem.luau` | Backpack/Character monitoring, Tool JSON serialization into Data.Inventory, restoration and globals |
| `ToolSetup.luau` | Tool/model creation helpers and alternate global factory |
| `MarketPlaceHandler/init.luau` | Sole ProcessReceipt registration: cash/building packs, shop items, skips, Build All, restocks and stealing |
| `MarketPlaceHandler/WebHook.luau` | Unreferenced outbound purchase webhook helper; contains a credential-bearing URL, do not print it or invoke it during audits |
| `RebirthConfig.luau` | Population requirements and income/population/XP multipliers |
| `RebirthSystem.luau` | Rebirth UI payloads, progress reset, intended preservation of Robux purchases |
| `TutorialSystem.luau` | Bank tool, construction/income/shack milestones, tutorial flags and analytics |
| `PostTutorialQuest.luau` | Five follow-on quests: collect income, construct three buildings, own eight buildings, place five roads, reach 100 population |
| `DailyRewards.luau` | Seven-day reward cycle, cash/buildings, 24-hour eligibility and streak state |
| `CodeSystem.luau` | Case-insensitive code redemption and separate redemption store |
| `CityNameSystem.luau` | City text filtering, separate name store, name cache and signs |
| `PlayerDataModule/init.luau` | Profile serialization/loading, schema migration, 60-second autosave and BindToClose |
| `BadgeModule.luau` | Badge ownership cache and awarding |
| `FunnelAnalytics.luau` | Nine tutorial steps and playtime milestones; quest analytics are commented out |
| `HighwayTrafficSystem.luau` | Cosmetic highway cars |
| `TrainSystem.luau` | Cosmetic trains |
| `WeatherSystem.luau` | Day/night transitions and building windows; main init disabled |
| `VFX.luau` | First Rare/Legendary effects, global lighting, audio and camera shake |

`src/shared` module roles:

| File | Responsibility |
| --- | --- |
| `Network.luau` | Shared remote schema, server-only creation and client replication wait |
| `Init.luau` | UI controller composition, shared UIEffects and tutorial selection |
| `UIController.luau` | HUD, menus, topbar, city names, rebirth UI, quests, daily rewards, building info and prompt labels |
| `TutorialController.luau` | Tutorial stages, text, beams, camera orbits and UI restoration; init starts tutorial itself |
| `ToolsModule.luau` | Tool preview, owned-land/collision presentation, dragging, rotation and placement request |
| `ShopController.luau` | Shop rows, purchase panels, price display and restock countdown |
| `SellController.luau` | Equipped-tool selling UI and preview cleanup |
| `NotificationController.luau` | Notification queue, sounds, deduplication and remote listeners |
| `FriendsBoost.luau` | Client friend-count display and boost reporting |
| `LikeSystem.luau` | City-rating toast listener |
| `UIEffects.luau` | HUD button hover/click/shine, including newly added buttons; per-button/container guards prevent duplicate bindings |

## Persistence contracts

- `Data_1`: profile JSON, keys based on player UserId; schema version 2.
  Envelope: `PlayerData`, `LeaderBoardData`, `LastSaved`. Do not change the namespace
  to hide bugs or silently reset players.
- `Data` owns `PlayerInfo`, `PlotInfo`, `OwnedTiles`, `Inventory`,
  `CurrentBuildings`, `CurrentConstructions`, plus template-defined folders.
- Tutorial flags live in `Data.PlayerInfo.Tutorial`; post-tutorial quest values
  live in `Data.PlayerInfo.Quests`; daily state is `Data.PlayerInfo.DailyRewards`.
- Inventory entries are StringValues containing JSON: Name, IsValid,
  BuildingLevel, BuildingXP, Mutation, RobuxBuilding. Tools can be in Backpack or
  equipped in Character.
- Placed-building CSV fields: relative XYZ, rotation XYZ, health, level, XP,
  RobuxBuilding (field 10). Construction CSV: remaining seconds, relative XYZ,
  rotation XYZ, size, last-update timestamp, level, XP, RobuxBuilding (field 12).
- Plots 5–8 use inverted X/Z and 180-degree rotation adjustments. Preserve paired
  save/load transforms.
- `CityNames`: city-name strings keyed by string UserId.
- `CityRatings`: `{likes, likedBy, lastUpdated}` keyed by `city_<UserId>`.
- `Codes`: redemption records keyed by `<UserId>_<UPPERCASE_CODE>`.
- Maintenance also mentions `Tutorial`; no active tutorial-store reader exists
  in this source. Never execute the maintenance utility to inspect data.
- No session ownership mechanism or durable receipt ledger exists. See audit.

## Authored hierarchy contracts

- `Workspace.Map.Plots.PlotN`: `Buildings.Placed`, `Buildings.Construction`,
  `Land.Owned`, `Land.Locked`, `Center`, `PlotSpawn`, and `UI` including CitySign,
  RatioSign, Overhead.Mugshot and CollectIncome. Construction is not directly under PlotN.
- `Workspace.Map.Enviorment.RoadSystem` and `.TrainSystem` hold cosmetic routes;
  `Workspace.Map.PlayerAnchors` holds tutorial beam anchors.
- `ServerStorage.PlotTemplate.PlotN` is the authored plot reset template.
- `Main.Items`: CollectPrompt, SkipPrompt, BuildingInfo, ConstructionInfo,
  SpeechBubble, RareVFX and LegendaryVFX remain Studio-owned.
- `PlayerDataModule.Data` and `.leaderstats` are required authored defaults.
- `ReplicatedStorage.Assets`: Highlight, Tool (ToolName/IsValid/Handle), Buildings,
  ToolBuildings, Constructions, CarTemplates, Trains.Train, Expansion.Locked and
  Expansion.Expansion.ExpansionPrompt.
- ShopController owns ItemTemplate/PurchaseFrame. TutorialController owns
  TutorialBeamAnchor/BeamTemplate. UIController owns IncomeBoostTemp,
  PopulationBoostTemp, BuildingTemp and WeatherTemplate. ToolsModule may own
  ArrowsGUI/BaseSelection. Do not manufacture replacement UI assets.
- Main GUI is `PlayerGui.HUD` cloned from `StarterGui.HUD`; initialize controllers
  with the HUD itself. It owns Frames, Buttons, NotificationsFrame, CashDisplay,
  FriendBoost, TutorialHandler, TutorialQuests, MobilePlacement and Weather.
- `ReplicatedStorage.TopbarPlus.Icon` remains an external module dependency.
- `ReplicatedStorage.Events` and `.Functions` are runtime-owned by Network.
  Events use feature subfolders; TutorialFinished remains directly under Events.
  Functions contains PlaceBlock and Friends.GetFriendBoost (moved from Events).
  Builder-limit notifications are `Events.Notifications.BuilderLimitReached`.
  Keep exact legacy spellings such as CodeFeeback and Recieved. Do not create
  client-only remotes or create remotes on first use. ControlPanel.Events belongs
  to an external admin system whose server code is absent; it is not managed here.

## Validation and next-work rules

Run from this project root:

```powershell
python tools/check_paths.py
& 'C:\Users\636922\.rokit\tool-storage\lune-org\lune\0.10.2\lune.exe' run tools/validate_source.luau
& 'C:\Users\636922\.rokit\tool-storage\lune-org\lune\0.10.2\lune.exe' run tools/test_startup.luau
& 'C:\Users\636922\.rokit\tool-storage\lune-org\lune\0.10.2\lune.exe' run tools/test_network.luau
```

The first resolves literal module paths and flags old roots. The second compiles
every source without executing it. The third uses mocks for client startup; it
does not run gameplay or contact Roblox. The network tests cover empty startup,
idempotence, preserved objects, delayed descendant replication, server-only
creation and wrong-class failures. Full engine integration is untested.

`tools/audit_studio.luau` is a read-only Command Bar script for EDIT mode. It checks
important authored paths (runtime remotes are intentionally excluded), reports
code outside sync roots, and flags old-path
candidates without printing source or touching persistence. It has not been run
against this place. Review outside-root results: third-party packages can be
intentional, whereas old HUD/Tool/loading scripts may still need exporting.

Prioritize the P0/P1 findings in `docs/BUG_AUDIT.md` before release claims. Fix
server authority and durable transactions with focused behavioral tests. Preserve
the existing art, GUI hierarchy, public product IDs and persistence namespace.
Do not infer completed Studio/multiplayer/receipt testing from static checks.
